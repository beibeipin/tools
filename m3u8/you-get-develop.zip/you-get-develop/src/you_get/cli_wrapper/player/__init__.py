#!/usr/bin/env python

from .mplayer import *
