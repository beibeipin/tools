#!/usr/bin/env python

''' WIP
def main():
    script_main('you-get', any_download, any_download_playlist)

if __name__ == "__main__":
    main()
'''
