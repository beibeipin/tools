#!/usr/bin/env zsh
alias you-get="noglob python3 $(dirname $0)/you-get"
alias you-vlc="noglob python3 $(dirname $0)/you-get --player vlc"
